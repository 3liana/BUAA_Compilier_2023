package paser_package;

import lexer_package.Token;

public class FuncType {
    private Token token;
    //void|int
    public FuncType(Token token){
        this.token = token;
    }
}
