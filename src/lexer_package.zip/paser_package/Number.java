package paser_package;

import lexer_package.Token;

public class Number {
    private Token token;
    public Number(Token token){
        this.token = token;
    }
}
