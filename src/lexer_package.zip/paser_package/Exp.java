package paser_package;

public class Exp {
    private AddExp addExp;
    public Exp(AddExp addExp){
        this.addExp = addExp;
    }
}
