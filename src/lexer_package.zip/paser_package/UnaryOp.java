package paser_package;

import lexer_package.Token;

public class UnaryOp {
    private Token op;
    public UnaryOp(Token op){
        this.op = op;
    }
}
