package paser_package;

public class Cond {
    private LOrExp exp;
    public Cond(LOrExp exp){
        this.exp = exp;
    }
}
