package paser_package;

public class Stmt {
    public Stmt() {

    }
}
