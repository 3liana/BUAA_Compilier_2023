package paser_package;

public class ConstExp {
    private AddExp addExp;
    public ConstExp(AddExp addExp){
        this.addExp = addExp;
    }
}
