package paser_package;

public class MainFuncDef {
    private Block block;
    public MainFuncDef(Block block){
        this.block = block;
    }
}
